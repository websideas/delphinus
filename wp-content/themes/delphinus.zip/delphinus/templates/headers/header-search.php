<?php
    if(!kt_option('header_search', 1)) return;
?>
<li class="search-action">
    <a href="#search-fullwidth" class="search-item"><i class="fa fa-search"></i></a>
</li>
