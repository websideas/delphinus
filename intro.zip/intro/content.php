<div class="site-content" id="content">
    <div class="page-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 ">
                    <div class="demo-item demo-item-left">
                        <a target="_blank" href="http://delphinus.kitethemes.com/index.php">
                            <span style="background-image:url(assets/images/Home_01.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/"> Home version 1 </a></h2>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="demo-item demo-item-right">
                        <a target="_blank" href="http://delphinus.kitethemes.com/home2">
                            <span style="background-image:url(assets/images/Home_02.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home2">Home version 2</a></h2>
                    </div>
                </div>
                <div class="col-sm-4 ">
                    <div class="demo-item demo-item-left">
                        <a target="_blank" href="http://delphinus.kitethemes.com/home3">
                            <span style="background-image:url(assets/images/Home_03.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home3">Home version 3</a></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="demo-item demo-item-right">
                        <a target="_blank" href="http://delphinus.kitethemes.com/home4">
                            <span style="background-image:url(assets/images/Home_04.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home4">Home version 4</a></h2>
                    </div>
                </div>
                <div class="col-sm-4 ">
                    <div class="demo-item demo-item-left">
                        <a target="_blank" href="http://delphinus.kitethemes.com/home5">
                            <span style="background-image:url(assets/images/Home_05.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home5">Home version 5</a></h2>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="demo-item demo-item-right">
                        <a target="_blank" href="http://delphinus.kitethemes.com/home6">
                            <span style="background-image:url(assets/images/Home_06.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home6">Home version 6</a></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="demo-item demo-item-left">
                        <a target="_blank" href="http://delphinus.kitethemes.com/home7">
                            <span style="background-image:url(assets/images/Home_07.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home7">Home version 7</a></h2>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="demo-item demo-item-right">
                        <a href="http://delphinus.kitethemes.com/home8">
                            <span style="background-image:url(assets/images/Home_08.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home8">Home version 8</a></h2>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="demo-item demo-item-left">
                        <a target="_blank" href="http://delphinus.kitethemes.com/home9">
                            <span style="background-image:url(assets/images/Home_09.jpg);" class="img-wrap move-long"></span>
                        </a>
                        <h2><a target="_blank" href="http://delphinus.kitethemes.com/home9">Home version 9</a></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>