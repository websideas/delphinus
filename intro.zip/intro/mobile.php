

<nav id="main-nav-mobile" class="main-nav-mobile"><ul id="menu-all-pages" class="menu navigation-mobile"><li id="menu-item-1638" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-701 current_page_item current-menu-ancestor current_page_ancestor menu-item-has-children menu-item-1638 menu-item-level-0 kt-menu-item kt-megamenu-item kt-megamenu-item-half" style=""><a href="http://delphinus.kitethemes.com/" class="kt-megamenu-link"><span>Home</span></a>
            <div class="kt-megamenu-wrapper  megamenu-position-center  megamenu-layout-default megamenu-columns-2 ">

                <ul class="kt-megamenu-ul clearfix">
                    <li id="menu-item-1977" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-1977 menu-item-level-1 kt-menu-item" style=""><span class="megamenu-title"><span>Home group 1</span></span>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-1979" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-701 current_page_item menu-item-1979 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/" class="kt-megamenu-link"><span>Front Page</span></a></li>
                            <li id="menu-item-1826" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1826 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-2/" class="kt-megamenu-link"><span>Home page 2</span></a></li>
                            <li id="menu-item-1825" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1825 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-3/" class="kt-megamenu-link"><span>Home page 3</span></a></li>
                            <li id="menu-item-1824" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1824 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-4/" class="kt-megamenu-link"><span>Home page 4</span></a></li>
                            <li id="menu-item-1823" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1823 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-5/" class="kt-megamenu-link"><span>Home page 5</span></a></li>
                        </ul>
                    </li>
                    <li id="menu-item-1978" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1978 menu-item-level-1 kt-menu-item" style=""><span class="megamenu-title"><span>Home group 2</span></span>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-1822" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1822 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-6/" class="kt-megamenu-link"><span>Home page 6</span></a></li>
                            <li id="menu-item-1821" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1821 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-7/" class="kt-megamenu-link"><span>Home page 7</span></a></li>
                            <li id="menu-item-1936" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1936 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-8/" class="kt-megamenu-link"><span>Home page 8</span></a></li>
                            <li id="menu-item-1935" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1935 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/home-page-9/" class="kt-megamenu-link"><span>Home page 9</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </li>
        <li id="menu-item-1706" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1706 menu-item-level-0 kt-menu-item kt-megamenu-item kt-megamenu-item-three" style=""><a href="http://delphinus.kitethemes.com/shop/" class="kt-megamenu-link"><span>Shop styles</span></a>
            <div class="kt-megamenu-wrapper  megamenu-position-center  megamenu-layout-table megamenu-columns-3 ">

                <ul class="kt-megamenu-ul clearfix">
                    <li id="menu-item-1920" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1920 menu-item-level-1 kt-menu-item" style=""><span class="megamenu-title"><span>Shop Style</span></span>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-2002" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2002 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/shop/?sidebar=left&#038;cols=2" class="kt-megamenu-link"><span>2 Column with sidebar</span></a></li>
                            <li id="menu-item-2001" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2001 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/shop/?sidebar=left&#038;cols=3" class="kt-megamenu-link"><span>3 Column with sidebar</span></a></li>
                            <li id="menu-item-2003" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2003 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/shop/?sidebar=left&#038;cols=3" class="kt-megamenu-link"><span>3 Column</span></a></li>
                            <li id="menu-item-2004" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2004 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/shop/?cols=4&#038;sidebar=" class="kt-megamenu-link"><span>4 Column</span></a></li>
                            <li id="menu-item-1742" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-1742 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product-category/living-room/" class="kt-megamenu-link"><span>Product Category</span></a></li>
                        </ul>
                    </li>
                    <li id="menu-item-1921" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1921 menu-item-level-1 kt-menu-item" style=""><span class="megamenu-title"><span>Product Detail</span></span>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-1927" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1927 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/patient-ninja/" class="kt-megamenu-link"><span>Product detail Style 1</span></a></li>
                            <li id="menu-item-1926" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1926 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/happy-ninja-2/" class="kt-megamenu-link"><span>Product detail Style 2</span></a></li>
                            <li id="menu-item-1925" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1925 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/product-detail-style-3/" class="kt-megamenu-link"><span>Product detail Style 3</span></a></li>
                            <li id="menu-item-2006" class="space menu-item menu-item-type-custom menu-item-object-custom menu-item-2006 menu-item-level-2 kt-menu-item" style=""><a href="#" class="kt-megamenu-link"><span>Space</span></a></li>
                            <li id="menu-item-2005" class="space menu-item menu-item-type-custom menu-item-object-custom menu-item-2005 menu-item-level-2 kt-menu-item" style=""><a href="#" class="kt-megamenu-link"><span>Space</span></a></li>
                        </ul>
                    </li>
                    <li id="menu-item-1922" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1922 menu-item-level-1 kt-menu-item" style=""><span class="megamenu-title"><span>Shop Page</span></span>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-1744" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1744 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/afteroom-chair/" class="kt-megamenu-link"><span>Standard Product</span></a></li>
                            <li id="menu-item-1748" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1748 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/patient-ninja/" class="kt-megamenu-link"><span>External Product</span></a></li>
                            <li id="menu-item-1741" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1741 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/ship-your-idea/" class="kt-megamenu-link"><span>Variable Product</span></a></li>
                            <li id="menu-item-1747" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1747 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/woo-single-1/" class="kt-megamenu-link"><span>Grouped Product</span></a></li>
                            <li id="menu-item-1746" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1746 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/product/ninja-silhouette-2/" class="kt-megamenu-link"><span>Out of Stock Product</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </li>
        <li id="menu-item-2026" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2026 menu-item-level-0 kt-menu-item" style=""><a href="#" class="kt-megamenu-link"><span>Page</span></a>
            <ul class="sub-menu-dropdown">
                <li id="menu-item-2028" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2028 menu-item-level-1 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/about-us/" class="kt-megamenu-link"><span>About us</span></a></li>
                <li id="menu-item-2027" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2027 menu-item-level-1 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/contact-us/" class="kt-megamenu-link"><span>Contact us</span></a></li>
                <li id="menu-item-1637" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1637 menu-item-level-1 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/blog/" class="kt-megamenu-link"><span>Blog</span></a></li>
                <li id="menu-item-2029" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2029 menu-item-level-1 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/the-best-way-to-clean-your-pillows/" class="kt-megamenu-link"><span>Blog detail</span></a></li>
            </ul>
        </li>
        <li id="menu-item-1646" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1646 menu-item-level-0 kt-menu-item kt-megamenu-item kt-megamenu-item-three" style=""><a href="http://delphinus.kitethemes.com/elements/" class="kt-megamenu-link"><span>Elements</span></a>
            <div class="kt-megamenu-wrapper  megamenu-position-center  megamenu-layout-table megamenu-columns-3 ">

                <ul class="kt-megamenu-ul clearfix">
                    <li id="menu-item-2042" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2042 menu-item-level-1 kt-menu-item" style=""><a href="#" class="kt-megamenu-link"><span>Elements group 1</span></a>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-2032" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2032 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/accordion/" class="kt-megamenu-link"><span>Accordion</span></a></li>
                            <li id="menu-item-2093" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2093 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/button/" class="kt-megamenu-link"><span>Button</span></a></li>
                            <li id="menu-item-2034" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2034 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/dividers/" class="kt-megamenu-link"><span>Dividers</span></a></li>
                            <li id="menu-item-1981" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1981 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/icon-box/" class="kt-megamenu-link"><span>Icon box</span></a></li>
                        </ul>
                    </li>
                    <li id="menu-item-2043" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2043 menu-item-level-1 kt-menu-item" style=""><a href="#" class="kt-megamenu-link"><span>Elements group 2</span></a>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-2033" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2033 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/client-logo/" class="kt-megamenu-link"><span>Client Logo</span></a></li>
                            <li id="menu-item-2035" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2035 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/google-map/" class="kt-megamenu-link"><span>Google map</span></a></li>
                            <li id="menu-item-2036" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2036 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/social-icon/" class="kt-megamenu-link"><span>Social Icon</span></a></li>
                            <li id="menu-item-1980" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1980 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/testimonial/" class="kt-megamenu-link"><span>Testimonial</span></a></li>
                        </ul>
                    </li>
                    <li id="menu-item-2044" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2044 menu-item-level-1 kt-menu-item" style=""><a href="#" class="kt-megamenu-link"><span>Elements group 3</span></a>
                        <ul class="sub-menu-megamenu">
                            <li id="menu-item-2037" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2037 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/socials/" class="kt-megamenu-link"><span>Socials</span></a></li>
                            <li id="menu-item-2038" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2038 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/sucbscribe-box/" class="kt-megamenu-link"><span>Sucbscribe Box</span></a></li>
                            <li id="menu-item-2039" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2039 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/team-member/" class="kt-megamenu-link"><span>Team member</span></a></li>
                            <li id="menu-item-2040" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2040 menu-item-level-2 kt-menu-item" style=""><a href="http://delphinus.kitethemes.com/elements/typography/" class="kt-megamenu-link"><span>Typography</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </li>
        <li id="menu-item-2080" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2080 menu-item-level-0 kt-menu-item" style=""><a href="#" class="kt-megamenu-link"><span>features</span></a></li>
        <li class="menu-item menu-item-language"><a href="#">Language: en</a><ul class="sub-menu-dropdown"><li class="current"><a href="http://localhost/delphinus"><span>EN</span></a></li></ul></li><li class="menu-item menu-item-currency"><a href="#">Currency: EUR</a><ul class="sub-menu-dropdown"><li class=""><a href="#" data-currency="USD" title="USA dollar"><span></span>USD</a><li class="active"><a href="#" data-currency="EUR" title="Europian Euro"><span></span>EUR</a></ul></li><li class="menu-item menu-item-myaccount"><a href="http://delphinus.kitethemes.com/my-account/">My Account</a><li class="menu-item menu-item-wishlist"><a href="http://delphinus.kitethemes.com/wishlist/?wishlist-action=view">wishlist</a></li><li class="menu-item menu-item-search-form">
            <form role="search" method="get" class="woocommerce-product-search searchform" action="http://delphinus.kitethemes.com/">
                <label class="screen-reader-text">Search</label>
                <input type="text" class="search-field" placeholder="Search Products&hellip;" value="" name="s" title="Search for:" />
                <button class="submit">
                    <i class="fa fa-search"></i>
                    <span>Search</span>
                </button>
                <input type="hidden" name="post_type" value="product" />
            </form>
        </li></ul></nav>