<div class="clearfix" id="header-content-mobile">
    <div class="header-content-mobile-inner">
        <div class="branding branding-mobile">
            <p class="site-logo retina-logo-wrapper">
                <a rel="home" href="http://delphinus.kitethemes.com/">
                    <img alt="Delphinus" class="default-logo" src="http://delphinus.kitethemes.com/wp-content/themes/delphinus/assets/images/logo.png">
                    <img alt="Delphinus" class="retina-logo retina-default-logo" src="http://delphinus.kitethemes.com/wp-content/themes/delphinus/assets/images/logo-2x.png">
                </a>
            </p><!-- .site-logo -->
        </div><!-- .site-branding -->

        <div class="header-mobile-tools">
            <a class="" id="hamburger-icon" href="#" title="Menu">
                <span class="hamburger-icon-inner">
                    <span class="line line-1"></span>
                    <span class="line line-2"></span>
                    <span class="line line-3"></span>
                </span>
            </a>
        </div>
    </div>
</div>
