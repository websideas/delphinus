</div><!-- #page -->

<!-- JS -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type="text/javascript" src="assets/js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script type="text/javascript" src="assets/libs/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>

<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript" src="assets/js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.matchHeight-min.js"></script>
<script type="text/javascript" src="assets/js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="assets/js/packery-mode.pkgd.min.js"></script>
<script type="text/javascript" src="assets/js/wow.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.superfish.custom.js"></script>
<script type="text/javascript" src="assets/libs/magnificPopup/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="assets/libs/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap-select.js"></script>
<script type="text/javascript" src="assets/js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="assets/js/jquery.cookie.js"></script>
<script type="text/javascript" src="assets/js/jquery.kt.sticky.js"></script>
<script type="text/javascript" src="assets/js/gmap3.min.js"></script>
<script type="text/javascript" src="assets/js/product-preview-slider.js"></script>


<!-- REVOLUTION JS FILES -->
<script type="text/javascript" src="assets/libs/revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="assets/libs/revolution/js/jquery.themepunch.revolution.min.js"></script>

<script type="text/javascript" src="assets/js/main.js"></script>

</body>
</html>