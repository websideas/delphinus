<?php

include_once('templates/headers/head.php');
include_once('templates/headers/header1.php');
include_once('templates/slideshows/slideshow.php');

?>
    <div id="main">




    </div><!-- #main -->
<?php

include_once('templates/footers/footer1.php');
include_once('templates/footers/footer.php');


