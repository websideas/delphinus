<?php
global $shadow;
$shadow = ' ';

include_once('templates/headers/head.php');
include_once('templates/headers/header1.php');

?>
    <div class="page-section bg-gray small-section">
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <ol class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li class="active">Banner</li>
                        </ol>
                    </div>
                    <div class="col-md-8 text-right">
                        <h1>Banner</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="main">




    </div><!-- #main -->
<?php

include_once('templates/footers/footer3.php');
include_once('templates/footers/footer.php');


