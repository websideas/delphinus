<?php

if(kt_is_wpml()) {
    echo kt_custom_wpml('<li class="language-switcher">', '</li>');
}