<nav class="main-nav" id="nav">
    <ul id="main-nav-tool">
        <li class="search-action">
            <a href="#search-fullwidth"><i class="fa fa-search"></i></a>
        </li>
    </ul><!-- #main-nav-tool -->
    <div class="container">
        <div class="main-navigation-outer">
            <?php include_once('templates/menu.php'); ?>
        </div>
    </div>
</nav><!-- .main-nav -->