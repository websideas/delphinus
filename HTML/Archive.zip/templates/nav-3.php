<nav class="main-nav" id="nav">
    <div class="container">
        <div class="main-navigation-outer">
            <?php include_once('templates/menu.php'); ?>
        </div>
    </div>
</nav><!-- .main-nav -->