<nav class="main-nav" id="nav">
        <div class="main-navigation-outer">
            <?php include_once('templates/menu.php'); ?>
        </div>
</nav><!-- .main-nav -->